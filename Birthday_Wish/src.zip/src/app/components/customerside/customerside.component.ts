import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerside',
  templateUrl: './customerside.component.html',
  styleUrls: ['./customerside.component.css']
})
export class CustomersideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
