import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminside',
  templateUrl: './adminside.component.html',
  styleUrls: ['./adminside.component.css']
})
export class AdminsideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
