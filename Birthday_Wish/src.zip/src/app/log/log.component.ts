import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.css']
})
export class LogComponent implements OnInit {
  text='';
  constructor(private data: DataService) {}
  
  
  ngOnInit(): void {
    this.data.share.subscribe(x => this.text = x);
  }

  onSubmit(): void {
   
  }

}
