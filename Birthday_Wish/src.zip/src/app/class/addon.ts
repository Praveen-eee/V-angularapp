export class addon{
    addOnid : number = 0;
    addonDescription:string = "";
    addOnName: string = "";
    addAddonPrice: string = "";
}