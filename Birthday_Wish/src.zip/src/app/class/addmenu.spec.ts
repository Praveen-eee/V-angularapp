import { Addmenu } from './addmenu';

describe('Addmenu', () => {
  it('should create an instance', () => {
    expect(new Addmenu()).toBeTruthy();
  });
});
