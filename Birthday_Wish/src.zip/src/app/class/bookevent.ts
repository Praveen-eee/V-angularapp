export class bookevent{
    eventId : number = 0;
    eventName:string = "";
    applicantName: string = "";
    applicantAddress: String="";
    applicantMobile: string = "";
    applicantEmail:string="";
    eventAddress:string="";
    eventDate:string="";
    eventTime:string="";
    eventMenuId:number=0;
    addonId:number=0;
    eventCost:String="";
}