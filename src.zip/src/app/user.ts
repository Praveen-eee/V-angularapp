export class User {
    id         ?:number;
    mailid    ?:String;
    password   ?:String;
}
