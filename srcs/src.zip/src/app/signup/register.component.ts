
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { User } from '../user';
import { UserserviceService } from 'src/app/services/userservice.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

// import { Customer } from '../customer';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registrationForm!: FormGroup;
  

  // get email(){
  //   return this.registrationForm.get('email')
  //   }
  //   get primEmail(){
  //     return this.registrationForm.get('primaryEmail')
  //     }
  constructor(private userService:UserserviceService,private fb: FormBuilder, 
    private router : Router) { }
  newuser : User = new User();

  // registrationForm = new FormGroup({
  //   primaryEmail: new FormControl('',[
  //     Validators.required,
  //     Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")])
  //   });

  // ngOnInit(): void {
  //   this.registrationForm = new FormGroup({
  //     primaryEmail: new FormControl('',[
  //       Validators.required,
  //       Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")])
  //     });
  // }

    ngOnInit(): void {
    this.registrationForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobileNumber: ['', [Validators.required, Validators.minLength(10)]],
      password: ['', [Validators.required
        // , Validators.minLength(6)
      ]],
      confirmPassword: ['', Validators.required]
    },  { validator: this.passwordMatchValidator }
    );
  }
  passwordMatchValidator(formGroup: FormGroup) {
    const password = formGroup.get('password')?.value;
    const confirmPassword = formGroup.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { passwordMismatch: true };
  }
  // onSubmit(admin_user:string){
  //   if(admin_user=="admin")
  //     this.router.navigate(['/admin']);
  //   else if(admin_user=="user")
  //     this.router.navigate(['/user']);
    
  // }  
  get f() { return this.registrationForm.controls; }

  onSubmit(){
    console.log(this.newuser);
    this.userService.storeUser(this.newuser).subscribe(data=>
      {
        console.log(data);
        alert("Registered Successfully");
      });
  }   

}
