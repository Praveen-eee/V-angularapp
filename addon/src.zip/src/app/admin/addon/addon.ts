export class addon{
    addOnid : number = 0;
    addOnDec:string = "";
    addOnName: string = "";
    addOnPrice: string = "";
}